// write the to print the patterns;
#include<stdio.h>
int main()
{
//	to print the vertical rectangle;
    printf("rectangle\n");
	printf("********\n");
	printf("*      *\n");
	printf("*      *\n");
	printf("*      *\n");
	printf("*      *\n");
	printf("*      *\n");
	printf("*      *\n");
	printf("*      *\n");
	printf("********\n");
	
//	to print the oval vertical circle;
     
     printf("oval rectangle\n");
     printf("   ***   \n");
     printf(" *      * \n");
     printf("*        *\n");
     printf("*        *\n");
     printf("*        *\n");
     printf("*        *\n");
     printf("*        *\n");
     printf(" *      * \n");
     printf("   ***   \n");
     
//     write the program to print arrow;
     
     printf("arrow pattern\n");
     printf("  *  \n");
     printf(" *** \n");
     printf("*****\n");
     printf("  *  \n");
     printf("  *  \n");
     printf("  *  \n");
     printf("  *  \n");
     printf("  *  \n");
     printf("  *  \n");
     
//     write the program to print the hollow diamond;
       
     printf("hollow diamond\n");  
     printf("    *    \n");
     printf("   * *   \n");
     printf("  *   *   \n");
     printf(" *     *   \n");
     printf("*       *   \n");
     printf(" *     *    \n");
     printf("  *   *      \n");
     printf("   * *        \n");
     printf("    *          \n");
     
     return 0;
     

}