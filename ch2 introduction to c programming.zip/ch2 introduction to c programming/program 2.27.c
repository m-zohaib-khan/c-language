// write the program to print the checkboard patterns of asterisk;
#include<stdio.h>
int main()
{
	printf("********\n");
	printf(" ********\n");
	printf("********\n");
	printf(" ********\n");
	printf("********\n");
	printf(" ********\n");
	printf("********\n");
	printf(" ********\n");
	
	return 0;
}